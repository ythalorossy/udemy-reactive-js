import moment from "moment";
import $ from "jquery";

$("body").text(moment().format());