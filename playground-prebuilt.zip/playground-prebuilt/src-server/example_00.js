import moment from "moment";

console.log(moment().format());

console.log("HELLO WORLD");